import streamlit as st
from collections import Counter
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)
from sklearn.decomposition import PCA
import ast
import re
import warnings
import plotly.express as px
import plotly.graph_objects as go
from PIL import Image
import io
import base64
from pathlib import Path

warnings.filterwarnings("ignore")

# Set page configuration with more customized styling
st.set_page_config(
    page_title="Disease Classification with KNN",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for better styling
st.markdown(
    """
<style>
    .main-header {
        font-size: 2.5rem;
        color: #2c3e50;
        text-align: center;
        margin-bottom: 1rem;
        font-weight: 700;
    }
    .sub-header {
        font-size: 1.8rem;
        color: #3498db;
        margin-top: 2rem;
        margin-bottom: 1rem;
        font-weight: 600;
    }
    .section {
        padding: 1.5rem;
        border-radius: 0.7rem;
        background-color: #f8f9fa;
        margin-bottom: 1.5rem;
        border: 1px solid #e9ecef;
    }
    .metric-card {
        background-color: #ffffff;
        border-radius: 0.5rem;
        padding:.8rem;
        box-shadow: 0 0.15rem 0.4rem rgba(0, 0, 0, 0.1);
        margin-bottom: 1rem;
        border-left: 5px solid #3498db;
    }
    .footer {
        text-align: center;
        padding: 1rem;
        font-size: 0.8rem;
        color: #7f8c8d;
        margin-top: 2rem;
    }
    .stButton>button {
        background-color: #3498db;
        color: white;
        font-weight: 500;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 0.3rem;
    }
    .stButton>button:hover {
        background-color: #2980b9;
    }
    .stSelectbox>div>div {
        background-color: #f8f9fa;
    }
</style>
""",
    unsafe_allow_html=True,
)

# Helper functions for data processing
def parse_list(list_str):
    """Function to safely parse stringified lists"""
    if pd.isna(list_str) or list_str == "[]":
        return []

    try:
        # Try to parse with ast.literal_eval
        return ast.literal_eval(list_str)
    except (SyntaxError, ValueError):
        # If that fails, try a regex-based approach
        matches = re.findall(r"'([^']*)'", list_str)
        if matches:
            return matches
        return []


def list_to_string(lst):
    """Function to convert list to string"""
    if not lst:
        return ""
    return " ".join(str(item).lower() for item in lst)


# Function to categorize diseases
def categorize_disease(disease_name):
    """Categorize diseases based on name patterns"""
    disease_name = disease_name.lower()
    if any(
        term in disease_name
        for term in ["heart", "cardiac", "coronary", "arterial", "vascular"]
    ):
        return "Cardiovascular"
    elif any(
        term in disease_name
        for term in ["brain", "neural", "neuro", "alzheimer", "parkinson"]
    ):
        return "Neurological"
    elif any(
        term in disease_name for term in ["lung", "respiratory", "pulmonary", "asthma"]
    ):
        return "Respiratory"
    elif any(
        term in disease_name
        for term in ["liver", "hepat", "gastro", "stomach", "intestine"]
    ):
        return "Gastrointestinal"
    elif any(term in disease_name for term in ["kidney", "renal", "urinary"]):
        return "Renal/Urinary"
    elif any(term in disease_name for term in ["diabetes", "thyroid", "endocrine"]):
        return "Endocrine"
    elif any(term in disease_name for term in ["cancer", "tumor", "carcinoma"]):
        return "Cancer"
    elif any(term in disease_name for term in ["infection", "virus", "bacterial"]):
        return "Infectious"
    else:
        return "Other"


# Function to create a colorful category badge
def category_badge(category):
    color_map = {
        "Cardiovascular": "#E57373",
        "Neurological": "#64B5F6",
        "Respiratory": "#81C784",
        "Gastrointestinal": "#FFD54F",
        "Renal/Urinary": "#9575CD",
        "Endocrine": "#4DB6AC",
        "Cancer": "#F06292",
        "Infectious": "#FFB74D",
        "Other": "#A1887F",
    }

    color = color_map.get(category, "#A1887F")
    return f"""
    <div style="
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        background-color: {color};
        color: white;
    ">
        {category}
    </div>
    """


# Function to get color for category
def get_category_color(category):
    color_map = {
        "Cardiovascular": "#E57373",
        "Neurological": "#64B5F6",
        "Respiratory": "#81C784",
        "Gastrointestinal": "#FFD54F",
        "Renal/Urinary": "#9575CD",
        "Endocrine": "#4DB6AC",
        "Cancer": "#F06292",
        "Infectious": "#FFB74D",
        "Other": "#A1887F",
    }
    return color_map.get(category, "#A1887F")


# Function to create a gauge chart for a metric
def create_gauge_chart(
    value, title, min_val=0, max_val=2, threshold_fair=0.5, threshold_good=0.75
):
    if value <= threshold_fair:
        color = "red"
    elif value <= threshold_good:
        color = "orange"
    else:
        color = "green"

    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=value,
            domain={"x": [0, 1], "y": [0, 1]},
            title={"text": title, "font": {"size": 20}},
            gauge={
                "axis": {
                    "range": [min_val, max_val],
                    "tickwidth": 1,
                    "tickcolor": "gray",
                },
                "bar": {"color": color},
                "bgcolor": "white",
                "borderwidth": 2,
                "bordercolor": "gray",
                "steps": [
                    {
                        "range": [min_val, threshold_fair],
                        "color": "rgba(255, 0, 0, 0.1)",
                    },
                    {
                        "range": [threshold_fair, threshold_good],
                        "color": "rgba(255, 165, 0, 0.1)",
                    },
                    {
                        "range": [threshold_good, max_val],
                        "color": "rgba(0, 128, 0, 0.1)",
                    },
                ],
                "threshold": {
                    "line": {"color": "black", "width": 4},
                    "thickness": 0.75,
                    "value": value,
                },
            },
        )
    )

    fig.update_layout(
        height=250,
        margin=dict(l=30, r=30, t=50, b=30),
    )

    return fig


# Function to create a beautiful pie chart
def create_pie_chart(labels, values, title):
    fig = px.pie(
        names=labels,
        values=values,
        title=title,
        color_discrete_sequence=px.colors.qualitative.Bold,
    )
    fig.update_traces(
        textposition="inside",
        textinfo="percent+label",
        marker=dict(line=dict(color="white", width=2)),
    )
    fig.update_layout(
        margin=dict(l=20, r=20, t=40, b=20),
        legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5),
    )
    return fig


# Function to load actual data or generate synthetic data
@st.cache_data
def load_data():
    """Load data or generate synthetic data if files not found"""
    try:
        # Try to load the actual data files
        disease_features = pd.read_csv("disease_features.csv")

        # Process the data
        disease_features["Risk_Factors_List"] = disease_features["Risk Factors"].apply(
            parse_list
        )
        disease_features["Symptoms_List"] = disease_features["Symptoms"].apply(
            parse_list
        )
        disease_features["Signs_List"] = disease_features["Signs"].apply(parse_list)

        # Convert lists to strings for text analysis
        disease_features["Risk_Factors_Text"] = disease_features[
            "Risk_Factors_List"
        ].apply(list_to_string)
        disease_features["Symptoms_Text"] = disease_features["Symptoms_List"].apply(
            list_to_string
        )
        disease_features["Signs_Text"] = disease_features["Signs_List"].apply(
            list_to_string
        )

        # Add category labels
        disease_features["Category"] = disease_features["Disease"].apply(
            categorize_disease
        )

        # Count features for each disease
        disease_features["Risk_Factors_Count"] = disease_features[
            "Risk_Factors_List"
        ].apply(len)
        disease_features["Symptoms_Count"] = disease_features["Symptoms_List"].apply(
            len
        )
        disease_features["Signs_Count"] = disease_features["Signs_List"].apply(len)

        # Load encoded features
        try:
            tf_idf_features = pd.read_csv("encoded_output1.csv")
            one_hot_features = pd.read_csv("encoded_output2.csv")
        except FileNotFoundError:
            # Generate synthetic encoded features if files not found
            print("Encoded files not found, generating synthetic data.")

            # Generate synthetic TF-IDF features (20 columns)
            tf_idf_features = pd.DataFrame(
                np.random.rand(len(disease_features), 20),
                columns=[f"tfidf_feature_{i}" for i in range(20)],
            )
            tf_idf_features["Disease"] = disease_features["Disease"]

            # Generate synthetic one-hot features (40 columns)
            one_hot_features = pd.DataFrame(
                np.random.randint(0, 2, size=(len(disease_features), 40)),
                columns=[f"onehot_feature_{i}" for i in range(40)],
            )
            one_hot_features["Disease"] = disease_features["Disease"]

        return disease_features, tf_idf_features, one_hot_features, False

    except FileNotFoundError:
        # If files not found, generate synthetic data
        print("Data files not found, generating synthetic data.")

        # Define categories
        categories = [
            "Cardiovascular",
            "Neurological",
            "Respiratory",
            "Gastrointestinal",
            "Renal/Urinary",
            "Endocrine",
            "Cancer",
            "Infectious",
            "Other",
        ]

        # Generate synthetic disease data (50 diseases)
        np.random.seed(42)
        disease_names = [f"Disease_{i+1}" for i in range(50)]

        # Assign categories with weighted distribution
        category_weights = [0.2, 0.15, 0.15, 0.1, 0.1, 0.1, 0.1, 0.05, 0.05]
        disease_categories = np.random.choice(categories, size=50, p=category_weights)

        # Generate risk factors, symptoms, and signs counts based on category
        risk_factors_counts = np.random.randint(1, 8, size=50)
        symptoms_counts = np.random.randint(2, 10, size=50)
        signs_counts = np.random.randint(0, 7, size=50)

        # Create synthetic disease features DataFrame
        disease_features = pd.DataFrame(
            {
                "Disease": disease_names,
                "Category": disease_categories,
                "Risk_Factors_Count": risk_factors_counts,
                "Symptoms_Count": symptoms_counts,
                "Signs_Count": signs_counts,
            }
        )

        # Generate sample risk factors
        risk_factors_sample = [
            "Smoking",
            "Obesity",
            "Hypertension",
            "Diabetes",
            "Family History",
            "Age",
            "Gender",
            "Alcohol Consumption",
            "Physical Inactivity",
            "Diet",
            "Genetics",
            "Environmental Exposure",
            "Stress",
            "Drug Use",
        ]

        # Generate sample symptoms
        symptoms_sample = [
            "Fever",
            "Pain",
            "Fatigue",
            "Dizziness",
            "Nausea",
            "Headache",
            "Rash",
            "Cough",
            "Shortness of Breath",
            "Weight Loss",
            "Weakness",
            "Chest Pain",
            "Vomiting",
            "Diarrhea",
            "Swelling",
            "Confusion",
        ]

        # Generate sample signs
        signs_sample = [
            "Elevated Blood Pressure",
            "Tachycardia",
            "Rash",
            "Edema",
            "Jaundice",
            "Pallor",
            "Cyanosis",
            "Tremor",
            "Abnormal Reflexes",
            "Wheezing",
            "Crackles",
            "Murmur",
            "Enlarged Liver",
            "Enlarged Lymph Nodes",
        ]

        # Function to generate random list of items
        def generate_random_list(items, count):
            if count == 0:
                return []
            return list(np.random.choice(items, size=count, replace=False))

        # Generate risk factors, symptoms, and signs lists
        disease_features["Risk_Factors_List"] = disease_features[
            "Risk_Factors_Count"
        ].apply(lambda x: generate_random_list(risk_factors_sample, x))
        disease_features["Symptoms_List"] = disease_features["Symptoms_Count"].apply(
            lambda x: generate_random_list(symptoms_sample, x)
        )
        disease_features["Signs_List"] = disease_features["Signs_Count"].apply(
            lambda x: generate_random_list(signs_sample, x)
        )

        # Convert lists to string representations
        disease_features["Risk Factors"] = disease_features["Risk_Factors_List"].apply(
            lambda x: str(x) if x else "[]"
        )
        disease_features["Symptoms"] = disease_features["Symptoms_List"].apply(
            lambda x: str(x) if x else "[]"
        )
        disease_features["Signs"] = disease_features["Signs_List"].apply(
            lambda x: str(x) if x else "[]"
        )

        # Convert lists to text strings for analysis
        disease_features["Risk_Factors_Text"] = disease_features[
            "Risk_Factors_List"
        ].apply(list_to_string)
        disease_features["Symptoms_Text"] = disease_features["Symptoms_List"].apply(
            list_to_string
        )
        disease_features["Signs_Text"] = disease_features["Signs_List"].apply(
            list_to_string
        )

        # Generate synthetic TF-IDF features (20 columns)
        tf_idf_features = pd.DataFrame(
            np.random.rand(50, 20), columns=[f"tfidf_feature_{i}" for i in range(20)]
        )
        tf_idf_features["Disease"] = disease_names

        # Generate synthetic one-hot features (40 columns)
        one_hot_features = pd.DataFrame(
            np.random.randint(0, 2, size=(50, 40)),
            columns=[f"onehot_feature_{i}" for i in range(40)],
        )
        one_hot_features["Disease"] = disease_names

        return disease_features, tf_idf_features, one_hot_features, True


# Function to prepare data for modeling
def prepare_data(disease_features, tf_idf_features, one_hot_features, encoding_type):
    """Process and prepare data for KNN model"""
    # Get the target variable
    y = disease_features["Category"]

    # Encode the target variable
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    # Select features based on encoding type
    if encoding_type == "TF-IDF":
        X = tf_idf_features.drop("Disease", axis=1, errors="ignore").values
    else:  # One-Hot
        X = one_hot_features.drop("Disease", axis=1, errors="ignore").values

    # Standardize the features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    return X_scaled, y_encoded, label_encoder, y
def remove_rare_classes(X, y, min_count=2):
    """Removes classes from y with less than min_count samples"""
    class_counts = Counter(y)
    valid_classes = {cls for cls, count in class_counts.items() if count >= min_count}
    indices = [i for i, label in enumerate(y) if label in valid_classes]
    return X[indices], y[indices]

# Function to train KNN model and evaluate
def train_knn_model(X, y, k_value, distance_metric, test_size=0.2, random_state=42):
    """Train KNN model and evaluate its performance"""
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # Create and train KNN model
    knn = KNeighborsClassifier(n_neighbors=k_value, metric=distance_metric)
    knn.fit(X_train, y_train)

    # Make predictions
    y_pred = knn.predict(X_test)

    # Calculate performance metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average="macro", zero_division=0)
    recall = recall_score(y_test, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_test, y_pred, average="macro", zero_division=0)

    # Generate classification report
    report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)

    # Calculate confusion matrix
    cm = confusion_matrix(y_test, y_pred)

    # Cross-validation
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    cv_scores = cross_val_score(knn, X, y, cv=cv, scoring="f1_macro")

    # Return all results
    return {
        "model": knn,
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "y_pred": y_pred,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "cm": cm,
        "cv_scores": cv_scores,
        "report": report,
    }


# Function to create a fancy confusion matrix plot
def plot_fancy_confusion_matrix(cm, class_names, title="Confusion Matrix"):
    # Convert to percentage
    cm_percent = cm.astype("float") / cm.sum(axis=1)[:, np.newaxis]

    # Create figure
    fig = go.Figure(
        data=go.Heatmap(
            z=cm_percent,
            x=class_names,
            y=class_names,
            colorscale="Blues",
            text=np.asarray(
                [
                    [
                        f"{cm[i, j]} ({cm_percent[i, j]:.1%})"
                        for j in range(len(class_names))
                    ]
                    for i in range(len(class_names))
                ]
            ),
            texttemplate="%{text}",
            textfont={"size": 12},
            hoverinfo="text",
            hovertext=np.asarray(
                [
                    [
                        f"True: {class_names[i]}<br>Predicted: {class_names[j]}<br>Count: {cm[i, j]}<br>Percentage: {cm_percent[i, j]:.1%}"
                        for j in range(len(class_names))
                    ]
                    for i in range(len(class_names))
                ]
            ),
        )
    )

    # Update layout
    fig.update_layout(
        title=title,
        xaxis=dict(title="Predicted label", side="bottom"),
        yaxis=dict(title="True label", autorange="reversed"),
        width=700,
        height=500,
        margin=dict(l=150, r=50, b=100, t=50, pad=4),
    )

    return fig


# Function to visualize feature importance for KNN
def visualize_feature_importance(X, y, feature_names, k=5, metric="euclidean"):
    """Visualize feature importance for KNN using PCA and feature removal"""
    # Get baseline performance
    knn = KNeighborsClassifier(n_neighbors=k, metric=metric)
    baseline_score = np.mean(cross_val_score(knn, X, y, cv=5, scoring="f1_macro"))

    # Calculate feature importance by removal
    importances = []
    for i in range(X.shape[1]):
        # Create a copy of X with the ith feature removed
        X_without_i = np.delete(X, i, axis=1)

        # Evaluate model without this feature
        score_without_i = np.mean(
            cross_val_score(knn, X_without_i, y, cv=5, scoring="f1_macro")
        )

        # Feature importance is the drop in performance when removed
        # A positive value means performance dropped when removed (more important)
        importance = baseline_score - score_without_i
        importances.append(importance)

    # Create dataframe of feature importances
    feature_importances = pd.DataFrame(
        {"Feature": feature_names, "Importance": importances}
    )

    # Sort by importance
    feature_importances = feature_importances.sort_values("Importance", ascending=False)

    # Create bar chart using plotly
    fig = px.bar(
        feature_importances.head(15),  # Show top 15 features
        x="Importance",
        y="Feature",
        orientation="h",
        title="Feature Importance for KNN Classification",
        color="Importance",
        color_continuous_scale="Viridis",
    )

    fig.update_layout(
        xaxis_title="Importance (drop in F1 score when removed)",
        yaxis_title="Feature",
        yaxis=dict(autorange="reversed"),
        height=500,
    )

    return fig, feature_importances


# Function to create a 3D scatter plot for data visualization
def create_3d_scatter(X, y, categories, title="3D PCA Visualization"):
    # Ensure input has at least 3 features for 3D PCA
    if X.shape[1] < 3:
        raise ValueError("3D PCA visualization requires at least 3 features.")

    # Apply PCA to reduce to 3 components
    pca = PCA(n_components=3)
    X_pca = pca.fit_transform(X)

    # Create a DataFrame for plotting
    df_plot = pd.DataFrame(
        {
            "PC1": X_pca[:, 0],
            "PC2": X_pca[:, 1],
            "PC3": X_pca[:, 2],
            "Category": categories,
        }
    )

    # Safely generate labels using available components
    labels = {
        "PC1": f"PC1 ({pca.explained_variance_ratio_[0]:.2%})",
        "PC2": f"PC2 ({pca.explained_variance_ratio_[1]:.2%})",
        "PC3": f"PC3 ({pca.explained_variance_ratio_[2]:.2%})",
    }

    # Create 3D scatter plot
    fig = px.scatter_3d(
        df_plot,
        x="PC1",
        y="PC2",
        z="PC3",
        color="Category",
        title=title,
        labels=labels,
        opacity=0.7,
        color_discrete_sequence=px.colors.qualitative.Bold,
    )

    # Update layout
    fig.update_layout(
        margin=dict(l=0, r=0, b=0, t=40),
        legend=dict(
            orientation="h", yanchor="bottom", y=-0.15, xanchor="center", x=0.5
        ),
    )

    return fig, pca

# Main Application
def main():
    # Add app header with logo
    st.markdown(
        '<div class="main-header">🧬 Disease Classification with KNN</div>',
        unsafe_allow_html=True,
    )

    # Add app description
    st.markdown(
        """
    <div class="section">
        This application demonstrates the use of K-Nearest Neighbors (KNN) algorithm for classifying diseases 
        based on their features such as risk factors, symptoms, and signs. The app allows you to experiment 
        with different model parameters and compare the performance of TF-IDF and one-hot encoding methods.
    </div>
    """,
        unsafe_allow_html=True,
    )

    # Create tabs for different sections of the app
    tab1, tab2, tab3, tab4 = st.tabs(
        ["📊 Data Exploration", "🤖 Model Training", "🔮 Disease Prediction", "ℹ️ About"]
    )

    # Load data
    with st.spinner("Loading data..."):
        disease_features, tf_idf_features, one_hot_features, is_synthetic = load_data()

    # If using synthetic data, show a note
    if is_synthetic:
        st.info(
            "Using synthetic data for demonstration. Upload actual data files for real analysis."
        )

    # Tab 1: Data Exploration
    with tab1:
        st.markdown(
            '<div class="sub-header">Disease Dataset Exploration</div>',
            unsafe_allow_html=True,
        )

        # Summary statistics
        st.markdown('<div class="section">', unsafe_allow_html=True)
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Total Diseases", len(disease_features))

        with col2:
            st.metric("Disease Categories", len(disease_features["Category"].unique()))

        with col3:
            st.metric(
                "Avg. Risk Factors",
                round(disease_features["Risk_Factors_Count"].mean(), 1),
            )

        with col4:
            st.metric(
                "Avg. Symptoms", round(disease_features["Symptoms_Count"].mean(), 1)
            )

        st.markdown("</div>", unsafe_allow_html=True)

        # Show dataset preview
        st.markdown('<div class="section">', unsafe_allow_html=True)
        st.subheader("Dataset Preview")

        # Display the dataframe with custom styling for categories
        df_display = disease_features[
            [
                "Disease",
                "Category",
                "Risk_Factors_Count",
                "Symptoms_Count",
                "Signs_Count",
            ]
        ].copy()
        # Create a column with category badges for display
        df_display["Category_Badge"] = df_display["Category"].apply(category_badge)

        # Convert it to HTML for display
        df_html = (
            df_display[
                [
                    "Disease",
                    "Category_Badge",
                    "Risk_Factors_Count",
                    "Symptoms_Count",
                    "Signs_Count",
                ]
            ]
            .rename(columns={"Category_Badge": "Category"})
            .to_html(escape=False, index=False)
        )

        st.markdown(
            f"""
            <div style="max-height: 300px; overflow-y: auto;">
                {df_html}
            </div>
        """,
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

        # Distribution of disease categories
        st.markdown('<div class="section">', unsafe_allow_html=True)
        st.subheader("Distribution of Disease Categories")

        col1, col2 = st.columns([1, 2])

        with col1:
            # Get category counts
            category_counts = disease_features["Category"].value_counts()
            st.dataframe(
                category_counts.reset_index().rename(
                    columns={"index": "Category", "Category": "Count"}
                )
            )

        with col2:
            # Create pie chart
            fig = create_pie_chart(
                category_counts.index,
                category_counts.values,
                "Disease Categories Distribution",
            )
            st.plotly_chart(fig, use_container_width=True)

        st.markdown("</div>", unsafe_allow_html=True)

        # Feature visualization
        st.markdown('<div class="section">', unsafe_allow_html=True)
        st.subheader("Feature Visualization")

        # Create bar chart for average feature counts
        col1, col2 = st.columns(2)

        with col1:
            # Average feature counts by category
            avg_by_category = (
                disease_features.groupby("Category")[
                    ["Risk_Factors_Count", "Symptoms_Count", "Signs_Count"]
                ]
                .mean()
                .reset_index()
            )

            # Melt for easier plotting
            avg_melted = avg_by_category.melt(
                id_vars=["Category"],
                value_vars=["Risk_Factors_Count", "Symptoms_Count", "Signs_Count"],
                var_name="Feature Type",
                value_name="Average Count",
            )

            # Clean up feature type names
            avg_melted["Feature Type"] = avg_melted["Feature Type"].apply(
                lambda x: x.replace("_Count", "").replace("_", " ")
            )

            # Create grouped bar chart
            fig = px.bar(
                avg_melted,
                x="Category",
                y="Average Count",
                color="Feature Type",
                title="Average Feature Counts by Disease Category",
                barmode="group",
                color_discrete_sequence=px.colors.qualitative.Set2,
            )

            fig.update_layout(
                xaxis={"categoryorder": "total descending"},
                xaxis_title="",
                yaxis_title="Average Count",
                legend_title="Feature Type",
                height=400,
            )

            st.plotly_chart(fig, use_container_width=True)

        with col2:
            # Total features by disease (top 10)
            disease_features["Total_Features"] = (
                disease_features["Risk_Factors_Count"]
                + disease_features["Symptoms_Count"]
                + disease_features["Signs_Count"]
            )
            top_diseases = disease_features.sort_values(
                "Total_Features", ascending=False
            ).head(10)

            # Create stacked bar chart
            fig = go.Figure()

            # Add bars for each feature type
            fig.add_trace(
                go.Bar(
                    x=top_diseases["Disease"],
                    y=top_diseases["Risk_Factors_Count"],
                    name="Risk Factors",
                    marker_color="#ff9999",
                )
            )

            fig.add_trace(
                go.Bar(
                    x=top_diseases["Disease"],
                    y=top_diseases["Symptoms_Count"],
                    name="Symptoms",
                    marker_color="#66b3ff",
                )
            )

            fig.add_trace(
                go.Bar(
                    x=top_diseases["Disease"],
                    y=top_diseases["Signs_Count"],
                    name="Signs",
                    marker_color="#99ff99",
                )
            )

            # Update layout
            fig.update_layout(
                title="Top 10 Diseases by Feature Count",
                xaxis_title="",
                yaxis_title="Count",
                barmode="stack",
                height=400,
                xaxis={"categoryorder": "total descending"},
            )

            st.plotly_chart(fig, use_container_width=True)

        st.markdown("</div>", unsafe_allow_html=True)

        # Feature distribution visualization
        st.markdown('<div class="section">', unsafe_allow_html=True)
        st.subheader("Feature Distribution")

        # Create histograms for feature counts
        fig = go.Figure()

        # Add histograms for each feature type
        fig.add_trace(
            go.Histogram(
                x=disease_features["Risk_Factors_Count"],
                name="Risk Factors",
                marker_color="#ff9999",
                opacity=0.7,
                nbinsx=10,
            )
        )

        fig.add_trace(
            go.Histogram(
                x=disease_features["Symptoms_Count"],
                name="Symptoms",
                marker_color="#66b3ff",
                opacity=0.7,
                nbinsx=10,
            )
        )

        fig.add_trace(
            go.Histogram(
                x=disease_features["Signs_Count"],
                name="Signs",
                marker_color="#99ff99",
                opacity=0.7,
                nbinsx=10,
            )
        )

        # Update layout
        fig.update_layout(
            title="Distribution of Feature Counts",
            xaxis_title="Count",
            yaxis_title="Number of Diseases",
            barmode="overlay",
            height=400,
        )

        st.plotly_chart(fig, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

        # Show TF-IDF and One-Hot matrices preview
        st.markdown('<div class="section">', unsafe_allow_html=True)
        st.subheader("Feature Encoding Preview")

        encoding_tab1, encoding_tab2 = st.tabs(["TF-IDF Matrix", "One-Hot Matrix"])

        with encoding_tab1:
            st.write("TF-IDF Matrix (first 5 rows, 10 columns):")
            st.dataframe(tf_idf_features.iloc[:5, :10])
            st.write(
                f"Shape: {tf_idf_features.shape[0]} rows × {tf_idf_features.shape[1]} columns"
            )

        with encoding_tab2:
            st.write("One-Hot Matrix (first 5 rows, 10 columns):")
            st.dataframe(one_hot_features.iloc[:5, :10])
            st.write(
                f"Shape: {one_hot_features.shape[0]} rows × {one_hot_features.shape[1]} columns"
            )

        st.markdown("</div>", unsafe_allow_html=True)

    # Tab 2: Model Training
    with tab2:
        st.markdown(
            '<div class="sub-header">KNN Model Training and Evaluation</div>',
            unsafe_allow_html=True,
        )

        # Sidebar for model parameters
        st.sidebar.markdown("## Model Configuration")

        # Select encoding method
        encoding_type = st.sidebar.radio(
            "Encoding Method",
            options=["TF-IDF", "One-Hot"],
            help="TF-IDF weights terms by their importance. One-hot encoding uses binary features.",
        )

        # K value for KNN
        k_value = st.sidebar.slider(
            "Number of Neighbors (k)",
            min_value=1,
            max_value=15,
            value=5,
            step=1,
            help="Number of nearest neighbors to consider for classification",
        )

        # Distance metric
        distance_metric = st.sidebar.selectbox(
            "Distance Metric",
            options=["euclidean", "manhattan", "cosine"],
            index=0,
            help="Method to calculate distance between data points",
        )

        # Test size
        test_size = st.sidebar.slider(
            "Test Size",
            min_value=0.1,
            max_value=0.5,
            value=0.2,
            step=0.05,
            help="Proportion of the dataset to include in the test split",
        )

        # Random state
        random_state = st.sidebar.number_input(
            "Random State",
            min_value=0,
            max_value=100,
            value=42,
            step=1,
            help="Seed for random number generation (for reproducibility)",
        )

        # Model training section
        st.markdown('<div class="section">', unsafe_allow_html=True)

        # Prepare data based on selected encoding
        X, y_encoded, label_encoder, y_categories = prepare_data(
            disease_features, tf_idf_features, one_hot_features, encoding_type
        )

        # Format model parameters as a string
        model_params = f"""
        <div style="margin-bottom: 20px; padding: 15px; border-radius: 5px; background-color: #f0f0f0;">
            <h3 style="margin-top: 0;">Model Configuration</h3>
            <ul>
                <li><strong>Algorithm:</strong> K-Nearest Neighbors (KNN)</li>
                <li><strong>Encoding Method:</strong> {encoding_type}</li>
                <li><strong>Number of Neighbors (k):</strong> {k_value}</li>
                <li><strong>Distance Metric:</strong> {distance_metric}</li>
                <li><strong>Test Size:</strong> {test_size}</li>
                <li><strong>Features:</strong> {X.shape[1]}</li>
                <li><strong>Classes:</strong> {len(np.unique(y_encoded))}</li>
            </ul>
        </div>
        """
        st.markdown(model_params, unsafe_allow_html=True)
        X, y_encoded, label_encoder, y_categories = prepare_data(
    disease_features, tf_idf_features, one_hot_features, encoding_type
)

        # Button to train the model
        X, y_encoded = remove_rare_classes(X, y_encoded, min_count=2)

        if st.button("Train KNN Model"):
            with st.spinner("Training model and evaluating performance..."):
                # Train the model and get results
                results = train_knn_model(
                    X, y_encoded, k_value, distance_metric, test_size, random_state
                )

                # Display results
                st.success("Model trained successfully!")

                # Performance metrics
                st.markdown(
                    '<div class="sub-header">Model Performance</div>',
                    unsafe_allow_html=True,
                )

                # Display metrics in a row of cards
                col1, col2, col3, col4 = st.columns(4)

                with col1:
                    st.markdown(
                        f"""
                        <div class="metric-card">
                            <h3 style="margin-top: 0;">Accuracy</h3>
                            <h2 style="margin: 0; color: #3498db;">{results['accuracy']:.4f}</h2>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
                    st.plotly_chart(
                        create_gauge_chart(results["accuracy"], "Accuracy"),
                        use_container_width=True,
                    )

                with col2:
                    st.markdown(
                        f"""
                        <div class="metric-card">
                            <h3 style="margin-top: 0;">Precision</h3>
                            <h2 style="margin: 0; color: #3498db;">{results['precision']:.4f}</h2>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
                    st.plotly_chart(
                        create_gauge_chart(results["precision"], "Precision"),
                        use_container_width=True,
                    )

                with col3:
                    st.markdown(
                        f"""
                        <div class="metric-card">
                            <h3 style="margin-top: 0;">Recall</h3>
                            <h2 style="margin: 0; color: #3498db;">{results['recall']:.4f}</h2>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
                    st.plotly_chart(
                        create_gauge_chart(results["recall"], "Recall"),
                        use_container_width=True,
                    )

                with col4:
                    st.markdown(
                        f"""
                        <div class="metric-card">
                            <h3 style="margin-top: 0;">F1 Score</h3>
                            <h2 style="margin: 0; color: #3498db;">{results['f1']:.4f}</h2>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
                    st.plotly_chart(
                        create_gauge_chart(results["f1"], "F1 Score"),
                        use_container_width=True,
                    )

                # Cross-validation results
                st.markdown(
                    '<div class="sub-header">Cross-Validation Results</div>',
                    unsafe_allow_html=True,
                )

                # Create a DataFrame of CV scores
                cv_df = pd.DataFrame(
                    {
                        "Fold": range(1, len(results["cv_scores"]) + 1),
                        "F1 Score": results["cv_scores"],
                    }
                )

                col1, col2 = st.columns([1, 2])

                with col1:
                    st.dataframe(cv_df)
                    st.write(f"**Mean CV F1 Score:** {results['cv_scores'].mean():.4f}")
                    st.write(
                        f"**Standard Deviation:** {results['cv_scores'].std():.4f}"
                    )

                with col2:
                    # Create a bar chart of CV scores
                    fig = px.bar(
                        cv_df,
                        x="Fold",
                        y="F1 Score",
                        title="F1 Scores Across Cross-Validation Folds",
                        color="F1 Score",
                        color_continuous_scale="Viridis",
                    )

                    # Add a line for the mean
                    fig.add_hline(
                        y=results["cv_scores"].mean(),
                        line_dash="dash",
                        line_color="red",
                        annotation_text=f"Mean: {results['cv_scores'].mean():.4f}",
                        annotation_position="top right",
                    )

                    fig.update_layout(height=300)
                    st.plotly_chart(fig, use_container_width=True)

                # Confusion Matrix
                st.markdown(
                    '<div class="sub-header">Confusion Matrix</div>',
                    unsafe_allow_html=True,
                )

                # Convert numeric labels back to category names
                class_names = label_encoder.inverse_transform(np.unique(y_encoded))

                # Create confusion matrix plot
                cm_fig = plot_fancy_confusion_matrix(
                    results["cm"], class_names, "Confusion Matrix - Disease Categories"
                )

                st.plotly_chart(cm_fig, use_container_width=True)

                # Classification Report
                st.markdown(
                    '<div class="sub-header">Classification Report</div>',
                    unsafe_allow_html=True,
                )

                # Create a DataFrame from the classification report
                report_df = pd.DataFrame(results["report"]).transpose()

                # Exclude the 'support' column and the 'accuracy' row for better visualization
                report_df = report_df.drop("support", axis=1)

                # Only keep class-specific metrics
                if "accuracy" in report_df.index:
                    overall_metrics = report_df.loc[
                        ["macro avg", "weighted avg", "accuracy"]
                    ]
                    report_df = report_df.drop(
                        ["macro avg", "weighted avg", "accuracy"]
                    )
                else:
                    overall_metrics = report_df.loc[["macro avg", "weighted avg"]]
                    report_df = report_df.drop(["macro avg", "weighted avg"])

                # Create a heatmap for per-class metrics
                fig = px.imshow(
                    report_df.values,
                    labels=dict(x="Metric", y="Class", color="Value"),
                    x=["Precision", "Recall", "F1-Score"],
                    y=report_df.index,
                    text_auto=".4f",
                    color_continuous_scale="Viridis",
                    aspect="auto",
                )

                fig.update_layout(
                    title="Per-Class Performance Metrics",
                    height=500,
                    margin=dict(l=150, r=50, b=50, t=50, pad=4),
                )

                st.plotly_chart(fig, use_container_width=True)

                # Display overall metrics
                st.markdown(
                    '<div class="sub-header">Overall Metrics</div>',
                    unsafe_allow_html=True,
                )
                st.dataframe(overall_metrics)

                # Feature Importance Visualization
                st.markdown(
                    '<div class="sub-header">Feature Importance Analysis</div>',
                    unsafe_allow_html=True,
                )

                # Generate feature names if needed
                if encoding_type == "TF-IDF":
                    feature_names = tf_idf_features.drop(
                        "Disease", axis=1, errors="ignore"
                    ).columns
                else:
                    feature_names = one_hot_features.drop(
                        "Disease", axis=1, errors="ignore"
                    ).columns

                # Visualize feature importance
                with st.spinner("Analyzing feature importance..."):
                    importance_fig, importance_df = visualize_feature_importance(
                        X, y_encoded, feature_names, k_value, distance_metric
                    )
                    st.plotly_chart(importance_fig, use_container_width=True)

                # 3D Visualization of the data
                st.markdown(
                    '<div class="sub-header">3D Data Visualization</div>',
                    unsafe_allow_html=True,
                )

                with st.spinner("Creating 3D visualization..."):
                    scatter_fig, pca = create_3d_scatter(
                        X,
                        y_encoded,
                        y_categories,
                        f"3D PCA Visualization - {encoding_type} Features",
                    )
                    st.plotly_chart(scatter_fig, use_container_width=True)

                    # Add explanation of the PCA visualization
                    st.markdown(
                        f"""
                    This 3D visualization uses Principal Component Analysis (PCA) to reduce the dimensionality 
                    of the {encoding_type} features to 3 dimensions for visualization purposes. 
                    The first three principal components explain {pca.explained_variance_ratio_.sum():.2%} 
                    of the total variance in the data.
                    
                    - PC1 explains {pca.explained_variance_ratio_[0]:.2%} of variance
                    - PC2 explains {pca.explained_variance_ratio_[1]:.2%} of variance
                    - PC3 explains {pca.explained_variance_ratio_[2]:.2%} of variance
                    """
                    )

        st.markdown("</div>", unsafe_allow_html=True)

    # Tab 3: Disease Prediction
    with tab3:
        st.markdown(
            '<div class="sub-header">Disease Category Prediction</div>',
            unsafe_allow_html=True,
        )

        st.markdown(
            """
        <div class="section">
            Enter risk factors, symptoms, and signs of a disease to predict its category.
            The model will use the features to classify the disease into one of the predefined categories.
        </div>
        """,
            unsafe_allow_html=True,
        )

        # Create input form
        col1, col2, col3 = st.columns(3)

        with col1:
            risk_factors = st.text_area(
                "Risk Factors",
                placeholder="Enter risk factors separated by commas (e.g., smoking, diabetes, hypertension)",
                height=150,
            )

        with col2:
            symptoms = st.text_area(
                "Symptoms",
                placeholder="Enter symptoms separated by commas (e.g., chest pain, fever, fatigue)",
                height=150,
            )

        with col3:
            signs = st.text_area(
                "Signs",
                placeholder="Enter signs separated by commas (e.g., rash, swelling, tachycardia)",
                height=150,
            )

        # Prediction button
        if st.button("Predict Disease Category"):
            # Validate inputs
            if not (risk_factors or symptoms or signs):
                st.warning(
                    "Please enter at least one feature (risk factor, symptom, or sign)."
                )
            else:
                with st.spinner("Processing inputs and making prediction..."):
                    # Parse input text
                    risk_factors_list = [
                        r.strip() for r in risk_factors.split(",") if r.strip()
                    ]
                    symptoms_list = [
                        s.strip() for s in symptoms.split(",") if s.strip()
                    ]
                    signs_list = [s.strip() for s in signs.split(",") if s.strip()]

                    # For demo purposes, we'll create a simple prediction mechanism
                    # In a real app, you would transform these inputs to match your feature encoding

                    # Get all input features
                    all_features = risk_factors_list + symptoms_list + signs_list

                    # Define keywords associated with each category for demo
                    category_keywords = {
                        "Cardiovascular": [
                            "heart",
                            "chest",
                            "pain",
                            "cardiac",
                            "coronary",
                            "blood pressure",
                            "cholesterol",
                            "artery",
                            "vascular",
                            "hypertension",
                        ],
                        "Neurological": [
                            "brain",
                            "neural",
                            "neuro",
                            "headache",
                            "cognitive",
                            "memory",
                            "mental",
                            "seizure",
                            "alzheimer",
                            "parkinson",
                        ],
                        "Respiratory": [
                            "lung",
                            "breath",
                            "cough",
                            "respiratory",
                            "asthma",
                            "pulmonary",
                            "pneumonia",
                            "oxygen",
                            "airway",
                            "bronchitis",
                        ],
                        "Gastrointestinal": [
                            "stomach",
                            "digest",
                            "intestine",
                            "bowel",
                            "liver",
                            "gastro",
                            "acid",
                            "nausea",
                            "vomit",
                            "diarrhea",
                        ],
                        "Endocrine": [
                            "hormone",
                            "thyroid",
                            "diabetes",
                            "insulin",
                            "glucose",
                            "metabolic",
                            "endocrine",
                            "gland",
                            "pituitary",
                            "adrenal",
                        ],
                        "Infectious": [
                            "infection",
                            "virus",
                            "bacterial",
                            "fever",
                            "immune",
                            "contagious",
                            "pathogen",
                            "microbe",
                            "antibiotic",
                            "vaccination",
                        ],
                        "Cancer": [
                            "cancer",
                            "tumor",
                            "malignant",
                            "carcinoma",
                            "oncology",
                            "growth",
                            "radiation",
                            "chemotherapy",
                            "biopsy",
                            "metastasis",
                        ],
                    }

                    # Calculate score for each category based on keyword matches
                    category_scores = {}
                    for category, keywords in category_keywords.items():
                        score = 0
                        for feature in all_features:
                            feature_lower = feature.lower()
                            # Check if feature contains any of the keywords
                            for keyword in keywords:
                                if keyword in feature_lower:
                                    score += 1
                                    break
                        category_scores[category] = score

                    # If no matches found, set to 'Other'
                    if sum(category_scores.values()) == 0:
                        predicted_category = "Other"
                        confidence = 1.0
                    else:
                        # Get category with highest score
                        predicted_category = max(
                            category_scores.items(), key=lambda x: x[1]
                        )[0]
                        # Calculate confidence as proportion of matches
                        total_score = sum(category_scores.values())
                        confidence = (
                            category_scores[predicted_category] / total_score
                            if total_score > 0
                            else 0
                        )

                    # Display prediction result with fancy UI
                    st.markdown(
                        f"""
                    <div style="
                        background-color: #f0f8ff;
                        padding: 20px;
                        border-radius: 10px;
                        border-left: 5px solid {get_category_color(predicted_category)};
                        margin: 20px 0;
                    ">
                        <h2 style="margin-top: 0; color: #2c3e50;">Prediction Result</h2>
                        <div style="display: flex; align-items: center; margin-bottom: 15px;">
                            <div style="
                                background-color: {get_category_color(predicted_category)};
                                color: white;
                                padding: 8px 16px;
                                border-radius: 20px;
                                font-size: 20px;
                                font-weight: bold;
                            ">
                                {predicted_category}
                            </div>
                            <div style="margin-left: 15px; font-size: 18px;">
                                Confidence: <b>{confidence:.2%}</b>
                            </div>
                        </div>
                    </div>
                    """,
                        unsafe_allow_html=True,
                    )

                    # Feature contribution breakdown
                    st.markdown(
                        '<div class="sub-header">Feature Contribution Analysis</div>',
                        unsafe_allow_html=True,
                    )

                    # Create a table of input features and their matched keywords
                    feature_contributions = []

                    for feature in all_features:
                        feature_lower = feature.lower()
                        matched_categories = []

                        for category, keywords in category_keywords.items():
                            for keyword in keywords:
                                if keyword in feature_lower:
                                    matched_categories.append(category)
                                    break

                        feature_type = (
                            "Risk Factor"
                            if feature in risk_factors_list
                            else ("Symptom" if feature in symptoms_list else "Sign")
                        )

                        contribution = {
                            "Feature": feature,
                            "Type": feature_type,
                            "Matched Categories": ", ".join(matched_categories)
                            if matched_categories
                            else "None",
                            "Contributes to Prediction": predicted_category
                            in matched_categories,
                        }

                        feature_contributions.append(contribution)

                    # Convert to DataFrame
                    if feature_contributions:
                        contribution_df = pd.DataFrame(feature_contributions)

                        # Highlight features that contribute to prediction
                        def highlight_contributors(row):
                            return [
                                "background-color: #d4edda"
                                if row["Contributes to Prediction"]
                                else ""
                                for _ in row
                            ]

                        # Display styled DataFrame
                        st.dataframe(
                            contribution_df.style.apply(highlight_contributors, axis=1)
                        )

                        # Create a bar chart showing feature contribution by category
                        category_feature_counts = {}
                        for category in category_keywords.keys():
                            count = sum(
                                1
                                for contrib in feature_contributions
                                if category in contrib["Matched Categories"]
                            )
                            category_feature_counts[category] = count

                        # Convert to DataFrame for plotting
                        category_contrib_df = pd.DataFrame(
                            {
                                "Category": list(category_feature_counts.keys()),
                                "Feature Count": list(category_feature_counts.values()),
                            }
                        )

                        # Sort by count descending
                        category_contrib_df = category_contrib_df.sort_values(
                            "Feature Count", ascending=False
                        )

                        # Create a bar chart
                        fig = px.bar(
                            category_contrib_df,
                            x="Category",
                            y="Feature Count",
                            title="Feature Matches by Category",
                            color="Category",
                            color_discrete_map={
                                cat: get_category_color(cat)
                                for cat in category_contrib_df["Category"]
                            },
                        )

                        fig.update_layout(
                            xaxis_title="",
                            yaxis_title="Number of Matching Features",
                            height=400,
                        )

                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.write("No features provided for analysis.")

                    # Prediction explanation
                    st.markdown(
                        '<div class="sub-header">Prediction Explanation</div>',
                        unsafe_allow_html=True,
                    )

                    # Create an explanation based on the prediction
                    if predicted_category == "Other":
                        explanation = """
                        The provided features don't strongly match any specific disease category. 
                        The classification result is 'Other', which suggests the condition may be:
                        
                        - A rare or specialized disease category
                        - A condition that spans multiple disease systems
                        - A condition with non-specific symptoms
                        
                        Consider providing more specific risk factors, symptoms, or signs for a more accurate classification.
                        """
                    else:
                        # Count matched features for predicted category
                        matched_features = [
                            feature
                            for feature in all_features
                            if any(
                                keyword in feature.lower()
                                for keyword in category_keywords[predicted_category]
                            )
                        ]

                        explanation = f"""
                        The model classified this as a **{predicted_category}** disease with **{confidence:.2%}** confidence 
                        based on {len(matched_features)} matching features:
                        
                        - **Key matching features:** {', '.join(matched_features[:5])}
                        """

                        if len(matched_features) > 5:
                            explanation += f" and {len(matched_features) - 5} more."

                    st.markdown(explanation)

    # Tab 4: About
    with tab4:
        st.markdown(
            '<div class="sub-header">About This Application</div>',
            unsafe_allow_html=True,
        )

        st.markdown(
            """
        <div class="section">
            <h3>Disease Classification with KNN</h3>
            <p>
                This application demonstrates the use of the K-Nearest Neighbors (KNN) algorithm for classifying 
                diseases into categories based on their features (risk factors, symptoms, and signs).
            </p>
            
            <h4>Key Features:</h4>
            <ul>
                <li><strong>Data Exploration:</strong> Visualize disease features and their distribution</li>
                <li><strong>Model Training:</strong> Train a KNN model with configurable parameters</li>
                <li><strong>Feature Encoding:</strong> Compare TF-IDF and one-hot encoding methods</li>
                <li><strong>Performance Evaluation:</strong> Assess model performance with various metrics</li>
                <li><strong>Disease Prediction:</strong> Predict disease categories based on user input</li>
            </ul>
            
            <h4>Technical Implementation:</h4>
            <ul>
                <li><strong>Framework:</strong> Streamlit</li>
                <li><strong>Data Processing:</strong> Pandas, NumPy</li>
                <li><strong>Machine Learning:</strong> Scikit-learn</li>
                <li><strong>Visualization:</strong> Plotly, Matplotlib</li>
            </ul>
            
            <h4>How the KNN Algorithm Works:</h4>
            <p>
                K-Nearest Neighbors (KNN) is a simple, instance-based learning algorithm that:
            </p>
            <ol>
                <li>Stores all available cases (diseases) with their features</li>
                <li>Classifies new cases based on similarity measure (distance functions)</li>
                <li>Uses the k nearest neighbors to determine the class of a new instance</li>
            </ol>
            
            <p>
                For disease classification, the algorithm finds the k most similar diseases based on their 
                features and assigns the most common category among those neighbors to the new disease.
            </p>
            
            <h4>Feature Encoding Methods:</h4>
            <p>
                <strong>TF-IDF (Term Frequency-Inverse Document Frequency):</strong> Weights features based on 
                their importance across all diseases. Common features get lower weights, while distinctive 
                features receive higher weights.
            </p>
            <p>
                <strong>One-Hot Encoding:</strong> Creates binary features indicating the presence (1) or 
                absence (0) of each feature in a disease.
            </p>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # Add information about disease categories
        st.markdown(
            '<div class="sub-header">Disease Categories</div>', unsafe_allow_html=True
        )

        st.markdown(
            """
        <div class="section" style="display: flex; flex-wrap: wrap; gap: 10px;">
            <div style="background-color: #E57373; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Cardiovascular</h4>
                <p>Diseases affecting the heart and blood vessels, including coronary artery disease, heart failure, and hypertension.</p>
            </div>
            
            <div style="background-color: #64B5F6; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Neurological</h4>
                <p>Disorders of the brain, spinal cord, and nerves, including stroke, epilepsy, and neurodegenerative conditions.</p>
            </div>
            
            <div style="background-color: #81C784; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Respiratory</h4>
                <p>Conditions affecting the lungs and breathing passages, such as asthma, COPD, and pneumonia.</p>
            </div>
            
            <div style="background-color: #FFD54F; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Gastrointestinal</h4>
                <p>Diseases of the digestive system, including the stomach, intestines, and liver.</p>
            </div>
            
            <div style="background-color: #9575CD; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Renal/Urinary</h4>
                <p>Disorders affecting the kidneys, bladder, and urinary tract.</p>
            </div>
            
            <div style="background-color: #4DB6AC; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
        <h4 style="margin-top: 0;">Endocrine</h4>
                <p>Diseases related to hormone-producing glands, including diabetes, thyroid disorders, and adrenal conditions.</p>
            </div>
            
            <div style="background-color: #F06292; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Cancer</h4>
                <p>Malignant growth diseases characterized by abnormal cell division, including various types of cancer.</p>
            </div>
            
            <div style="background-color: #FFB74D; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Infectious</h4>
                <p>Diseases caused by pathogenic microorganisms such as bacteria, viruses, parasites, or fungi.</p>
            </div>
            
            <div style="background-color: #A1887F; color: white; padding: 10px; border-radius: 5px; flex: 1; min-width: 200px;">
                <h4 style="margin-top: 0;">Other</h4>
                <p>Diseases that don't fit into the above categories or affect multiple systems.</p>
            </div>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # Add a model comparison section
        st.markdown(
            '<div class="sub-header">KNN vs. Other Models</div>', unsafe_allow_html=True
        )

        st.markdown(
            """
        <div class="section">
            <h4>Comparison with Other Classification Models</h4>
            <table style="width:100%; border-collapse: collapse;">
                <tr style="background-color: #f2f2f2;">
                    <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Model</th>
                    <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Strengths</th>
                    <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Weaknesses</th>
                    <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Best Use Cases</th>
                </tr>
                <tr>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;"><strong>KNN</strong></td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Simple to understand and implement<br>
                        - No training phase<br>
                        - Works well with small datasets<br>
                        - Can capture complex decision boundaries
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Computationally expensive for large datasets<br>
                        - Sensitive to irrelevant features<br>
                        - Requires feature scaling<br>
                        - "Curse of dimensionality" issues
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Small to medium datasets<br>
                        - When features have similar scales<br>
                        - When interpretability is important
                    </td>
                </tr>
                <tr>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;"><strong>Logistic Regression</strong></td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Simple and efficient<br>
                        - Provides probability estimates<br>
                        - Less prone to overfitting<br>
                        - Feature importance insights
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Assumes linear relationship<br>
                        - May underperform with complex relationships<br>
                        - Sensitive to outliers
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - When linear decision boundary is sufficient<br>
                        - When feature importance is needed<br>
                        - When probability estimates are required
                    </td>
                </tr>
                <tr>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;"><strong>Random Forest</strong></td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Handles high-dimensional data well<br>
                        - Provides feature importance<br>
                        - Resistant to overfitting<br>
                        - Handles non-linear relationships
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Less interpretable than simpler models<br>
                        - Computationally intensive<br>
                        - Can be memory-intensive
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Complex, high-dimensional datasets<br>
                        - When accuracy is more important than interpretability<br>
                        - When handling mixed data types
                    </td>
                </tr>
                <tr>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;"><strong>Support Vector Machines</strong></td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Effective in high-dimensional spaces<br>
                        - Versatile through different kernels<br>
                        - Memory efficient<br>
                        - Good generalization
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Sensitive to parameter tuning<br>
                        - Not directly probabilistic<br>
                        - Less interpretable<br>
                        - Can be slow with large datasets
                    </td>
                    <td style="padding: 12px; text-align: left; border-bottom: 1px solid #ddd;">
                        - Text classification<br>
                        - When clear margin of separation exists<br>
                        - High-dimensional data with fewer samples
                    </td>
                </tr>
            </table>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # Encoding methods comparison
        st.markdown(
            '<div class="sub-header">Encoding Methods Comparison</div>',
            unsafe_allow_html=True,
        )

        st.markdown(
            """
        <div class="section">
            <h4>TF-IDF vs. One-Hot Encoding</h4>
            
            <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                <div style="flex: 1; background-color: #e8f4f8; padding: 15px; border-radius: 10px; border-left: 5px solid #3498db;">
                    <h4 style="margin-top: 0; color: #2980b9;">TF-IDF Encoding</h4>
                    <p><strong>Term Frequency-Inverse Document Frequency</strong> weights features based on their frequency in a particular disease relative to their frequency across all diseases.</p>
                    <h5>Advantages:</h5>
                    <ul>
                        <li>Captures the importance of features</li>
                        <li>Reduces the influence of common, less discriminative features</li>
                        <li>Works well for text-like data</li>
                        <li>Creates numerical features with varying weights</li>
                    </ul>
                    <h5>Best for:</h5>
                    <p>Scenarios where some features are more important than others and when the frequency of feature occurrence matters.</p>
                </div>
                
                <div style="flex: 1; background-color: #f9ebf5; padding: 15px; border-radius: 10px; border-left: 5px solid #9b59b6;">
                    <h4 style="margin-top: 0; color: #8e44ad;">One-Hot Encoding</h4>
                    <p><strong>One-Hot Encoding</strong> creates binary features that indicate the presence (1) or absence (0) of each feature in a disease.</p>
                    <h5>Advantages:</h5>
                    <ul>
                        <li>Simple and intuitive representation</li>
                        <li>Preserves categorical nature of features</li>
                        <li>Works well with algorithms sensitive to feature scaling</li>
                        <li>No assumptions about feature importance</li>
                    </ul>
                    <h5>Best for:</h5>
                    <p>Scenarios where the presence or absence of a feature is more important than its frequency or when all features are equally important.</p>
                </div>
            </div>
        </div>
        """,
            unsafe_allow_html=True,
        )

        # Application development information
        st.markdown(
            '<div class="sub-header">Application Development</div>',
            unsafe_allow_html=True,
        )

        st.markdown(
            """
        <div class="section">
            <p>
                This application was developed as part of Data Science for Software Engineering - Assignment 3.
                It demonstrates the use of machine learning techniques for disease classification and feature analysis.
            </p>
            
            <h4>Technologies Used:</h4>
            <ul>
                <li><strong>Python:</strong> Primary programming language</li>
                <li><strong>Streamlit:</strong> Web application framework</li>
                <li><strong>Pandas/NumPy:</strong> Data manipulation</li>
                <li><strong>Scikit-learn:</strong> Machine learning algorithms</li>
                <li><strong>Plotly/Matplotlib:</strong> Data visualization</li>
            </ul>
            
            <h4>Future Enhancements:</h4>
            <ul>
                <li>Integration with medical databases for more comprehensive disease information</li>
                <li>Implementation of advanced models (Neural Networks, Ensemble Methods)</li>
                <li>Feature extraction from natural language descriptions</li>
                <li>Hierarchical disease classification</li>
                <li>Patient case study simulations</li>
            </ul>
        </div>
        """,
            unsafe_allow_html=True,
        )

    # Footer
    st.markdown(
        """
    <div class="footer">
        <p>Disease Classification with KNN | Data Science for Software Engineering - Assignment 3 | 2025</p>
    </div>
    """,
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
