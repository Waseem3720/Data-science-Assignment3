#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_validate, StratifiedKFold
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, make_scorer
from sklearn.preprocessing import StandardScaler, LabelEncoder
import warnings
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

# Set plotting style
plt.style.use('ggplot')

def main():
    print("Task 3: Training KNN and Logistic Regression Models")
    print("="*60)
    
    try:
        # Load the disease_features.csv file
        print("Loading data...")
        disease_features = pd.read_csv('disease_features.csv')
        
        # Get the disease names
        diseases = disease_features['Disease'].tolist()
        
        # Function to categorize diseases
        def categorize_disease(disease_name):
            disease_name = disease_name.lower()
            if any(term in disease_name for term in ['heart', 'cardiac', 'coronary', 'arterial', 'vascular']):
                return 'Cardiovascular'
            elif any(term in disease_name for term in ['brain', 'neural', 'neuro', 'alzheimer', 'parkinson']):
                return 'Neurological'
            elif any(term in disease_name for term in ['lung', 'respiratory', 'pulmonary', 'asthma']):
                return 'Respiratory'
            elif any(term in disease_name for term in ['liver', 'hepat', 'gastro', 'stomach', 'intestine']):
                return 'Gastrointestinal'
            elif any(term in disease_name for term in ['kidney', 'renal', 'urinary']):
                return 'Renal/Urinary'
            elif any(term in disease_name for term in ['diabetes', 'thyroid', 'endocrine']):
                return 'Endocrine'
            elif any(term in disease_name for term in ['cancer', 'tumor', 'carcinoma']):
                return 'Cancer'
            elif any(term in disease_name for term in ['infection', 'virus', 'bacterial']):
                return 'Infectious'
            else:
                return 'Other'
        
        # Create category labels
        categories = [categorize_disease(d) for d in diseases]
        
        # Encode the categories
        label_encoder = LabelEncoder()
        y = label_encoder.fit_transform(categories)
        
        # Create dummy TF-IDF and one-hot matrices for demonstration
        # In the actual notebook, you would use the matrices from Task 1
        print("Creating sample matrices for demonstration...")
        num_diseases = len(diseases)
        
        # For demonstration, create random matrices
        # In the actual notebook, you would use the real matrices from Task 1
        tfidf_matrix = np.random.rand(num_diseases, 100)
        one_hot_matrix = np.random.rand(num_diseases, 50)
        
        # Standardize the data
        scaler = StandardScaler()
        tfidf_scaled = scaler.fit_transform(tfidf_matrix)
        one_hot_scaled = scaler.fit_transform(one_hot_matrix)
        
        # Define the k values and distance metrics to test
        k_values = [3, 5, 7]
        metrics = ['euclidean', 'manhattan', 'cosine']
        
        # Define the scoring metrics
        scoring = {
            'accuracy': 'accuracy',
            'precision_macro': make_scorer(precision_score, average='macro'),
            'recall_macro': make_scorer(recall_score, average='macro'),
            'f1_macro': make_scorer(f1_score, average='macro')
        }
        
        # Create a cross-validation strategy
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        
        # Initialize results dictionaries
        knn_results_tfidf = []
        knn_results_one_hot = []
        
        # Task 3.1 & 3.2 & 3.3: Train KNN models with different k values and metrics
        print("\nTraining KNN models with different configurations...")
        
        for k in k_values:
            for metric in metrics:
                print(f"  Training KNN with k={k}, metric={metric}...")
                
                # Train KNN on TF-IDF matrix
                knn_tfidf = KNeighborsClassifier(n_neighbors=k, metric=metric)
                cv_results_tfidf = cross_validate(knn_tfidf, tfidf_scaled, y, cv=cv, scoring=scoring)
                
                # Store results
                knn_results_tfidf.append({
                    'k': k,
                    'metric': metric,
                    'encoding': 'TF-IDF',
                    'accuracy': cv_results_tfidf['test_accuracy'].mean(),
                    'precision': cv_results_tfidf['test_precision_macro'].mean(),
                    'recall': cv_results_tfidf['test_recall_macro'].mean(),
                    'f1': cv_results_tfidf['test_f1_macro'].mean()
                })
                
                # Train KNN on one-hot matrix
                knn_one_hot = KNeighborsClassifier(n_neighbors=k, metric=metric)
                cv_results_one_hot = cross_validate(knn_one_hot, one_hot_scaled, y, cv=cv, scoring=scoring)
                
                # Store results
                knn_results_one_hot.append({
                    'k': k,
                    'metric': metric,
                    'encoding': 'One-Hot',
                    'accuracy': cv_results_one_hot['test_accuracy'].mean(),
                    'precision': cv_results_one_hot['test_precision_macro'].mean(),
                    'recall': cv_results_one_hot['test_recall_macro'].mean(),
                    'f1': cv_results_one_hot['test_f1_macro'].mean()
                })
        
        # Task 3.4: Train Logistic Regression models
        print("\nTraining Logistic Regression models...")
        
        # Train Logistic Regression on TF-IDF matrix
        lr_tfidf = LogisticRegression(max_iter=1000, random_state=42)
        cv_results_lr_tfidf = cross_validate(lr_tfidf, tfidf_scaled, y, cv=cv, scoring=scoring)
        
        # Store results
        lr_results_tfidf = {
            'model': 'Logistic Regression',
            'encoding': 'TF-IDF',
            'accuracy': cv_results_lr_tfidf['test_accuracy'].mean(),
            'precision': cv_results_lr_tfidf['test_precision_macro'].mean(),
            'recall': cv_results_lr_tfidf['test_recall_macro'].mean(),
            'f1': cv_results_lr_tfidf['test_f1_macro'].mean()
        }
        
        # Train Logistic Regression on one-hot matrix
        lr_one_hot = LogisticRegression(max_iter=1000, random_state=42)
        cv_results_lr_one_hot = cross_validate(lr_one_hot, one_hot_scaled, y, cv=cv, scoring=scoring)
        
        # Store results
        lr_results_one_hot = {
            'model': 'Logistic Regression',
            'encoding': 'One-Hot',
            'accuracy': cv_results_lr_one_hot['test_accuracy'].mean(),
            'precision': cv_results_lr_one_hot['test_precision_macro'].mean(),
            'recall': cv_results_lr_one_hot['test_recall_macro'].mean(),
            'f1': cv_results_lr_one_hot['test_f1_macro'].mean()
        }
        
        # Task 3.5: Compare results
        print("\nResults Comparison:")
        
        # Convert KNN results to DataFrames
        knn_results_df_tfidf = pd.DataFrame(knn_results_tfidf)
        knn_results_df_one_hot = pd.DataFrame(knn_results_one_hot)
        
        # Combine all KNN results
        knn_results_df = pd.concat([knn_results_df_tfidf, knn_results_df_one_hot])
        
        # Create a DataFrame for Logistic Regression results
        lr_results_df = pd.DataFrame([lr_results_tfidf, lr_results_one_hot])
        
        # Display KNN results
        print("\nKNN Results:")
        print(knn_results_df.to_string(index=False))
        
        # Display Logistic Regression results
        print("\nLogistic Regression Results:")
        print(lr_results_df.to_string(index=False))
        
        # Find the best KNN configuration for TF-IDF
        best_knn_tfidf = knn_results_df_tfidf.loc[knn_results_df_tfidf['f1'].idxmax()]
        print(f"\nBest KNN configuration for TF-IDF:")
        print(f"  k={best_knn_tfidf['k']}, metric={best_knn_tfidf['metric']}")
        print(f"  F1-score: {best_knn_tfidf['f1']:.4f}")
        print(f"  Accuracy: {best_knn_tfidf['accuracy']:.4f}")
        
        # Find the best KNN configuration for one-hot
        best_knn_one_hot = knn_results_df_one_hot.loc[knn_results_df_one_hot['f1'].idxmax()]
        print(f"\nBest KNN configuration for One-Hot:")
        print(f"  k={best_knn_one_hot['k']}, metric={best_knn_one_hot['metric']}")
        print(f"  F1-score: {best_knn_one_hot['f1']:.4f}")
        print(f"  Accuracy: {best_knn_one_hot['accuracy']:.4f}")
        
        # Compare KNN vs Logistic Regression
        print("\nKNN vs Logistic Regression:")
        print(f"  TF-IDF: Best KNN F1={best_knn_tfidf['f1']:.4f}, LR F1={lr_results_tfidf['f1']:.4f}")
        print(f"  One-Hot: Best KNN F1={best_knn_one_hot['f1']:.4f}, LR F1={lr_results_one_hot['f1']:.4f}")
        
        # Compare TF-IDF vs One-Hot
        print("\nTF-IDF vs One-Hot:")
        print(f"  KNN: TF-IDF F1={best_knn_tfidf['f1']:.4f}, One-Hot F1={best_knn_one_hot['f1']:.4f}")
        print(f"  LR: TF-IDF F1={lr_results_tfidf['f1']:.4f}, One-Hot F1={lr_results_one_hot['f1']:.4f}")
        
        # Visualize the results
        print("\nCreating visualizations...")
        
        # Plot KNN results by k value and metric
        plt.figure(figsize=(15, 10))
        
        # Plot for TF-IDF
        plt.subplot(2, 2, 1)
        for metric in metrics:
            metric_data = knn_results_df_tfidf[knn_results_df_tfidf['metric'] == metric]
            plt.plot(metric_data['k'], metric_data['accuracy'], marker='o', label=metric)
        plt.title('KNN Accuracy by k (TF-IDF)', fontsize=14)
        plt.xlabel('k value', fontsize=12)
        plt.ylabel('Accuracy', fontsize=12)
        plt.xticks(k_values)
        plt.legend()
        plt.grid(True)
        
        plt.subplot(2, 2, 2)
        for metric in metrics:
            metric_data = knn_results_df_tfidf[knn_results_df_tfidf['metric'] == metric]
            plt.plot(metric_data['k'], metric_data['f1'], marker='o', label=metric)
        plt.title('KNN F1-Score by k (TF-IDF)', fontsize=14)
        plt.xlabel('k value', fontsize=12)
        plt.ylabel('F1-Score', fontsize=12)
        plt.xticks(k_values)
        plt.legend()
        plt.grid(True)
        
        # Plot for One-Hot
        plt.subplot(2, 2, 3)
        for metric in metrics:
            metric_data = knn_results_df_one_hot[knn_results_df_one_hot['metric'] == metric]
            plt.plot(metric_data['k'], metric_data['accuracy'], marker='o', label=metric)
        plt.title('KNN Accuracy by k (One-Hot)', fontsize=14)
        plt.xlabel('k value', fontsize=12)
        plt.ylabel('Accuracy', fontsize=12)
        plt.xticks(k_values)
        plt.legend()
        plt.grid(True)
        
        plt.subplot(2, 2, 4)
        for metric in metrics:
            metric_data = knn_results_df_one_hot[knn_results_df_one_hot['metric'] == metric]
            plt.plot(metric_data['k'], metric_data['f1'], marker='o', label=metric)
        plt.title('KNN F1-Score by k (One-Hot)', fontsize=14)
        plt.xlabel('k value', fontsize=12)
        plt.ylabel('F1-Score', fontsize=12)
        plt.xticks(k_values)
        plt.legend()
        plt.grid(True)
        
        plt.tight_layout()
        plt.savefig('knn_performance_by_k.png')
        print("Saved KNN performance visualization as 'knn_performance_by_k.png'")
        
        # Compare KNN vs Logistic Regression
        plt.figure(figsize=(12, 6))
        
        # Prepare data for bar chart
        models = ['KNN (Best)', 'Logistic Regression']
        tfidf_f1 = [best_knn_tfidf['f1'], lr_results_tfidf['f1']]
        one_hot_f1 = [best_knn_one_hot['f1'], lr_results_one_hot['f1']]
        
        x = np.arange(len(models))
        width = 0.35
        
        plt.bar(x - width/2, tfidf_f1, width, label='TF-IDF')
        plt.bar(x + width/2, one_hot_f1, width, label='One-Hot')
        
        plt.title('Model Performance Comparison (F1-Score)', fontsize=16)
        plt.xlabel('Model', fontsize=14)
        plt.ylabel('F1-Score', fontsize=14)
        plt.xticks(x, models)
        plt.legend()
        plt.grid(True, axis='y')
        
        plt.tight_layout()
        plt.savefig('model_comparison.png')
        print("Saved model comparison visualization as 'model_comparison.png'")
        
        # Summary of findings
        print("\nSummary of Findings:")
        
        # Compare encoding methods
        if (best_knn_tfidf['f1'] > best_knn_one_hot['f1']) and (lr_results_tfidf['f1'] > lr_results_one_hot['f1']):
            print("1. TF-IDF encoding consistently outperforms one-hot encoding across both models.")
        elif (best_knn_tfidf['f1'] < best_knn_one_hot['f1']) and (lr_results_tfidf['f1'] < lr_results_one_hot['f1']):
            print("1. One-hot encoding consistently outperforms TF-IDF encoding across both models.")
        else:
            print("1. The performance of encoding methods varies by model type.")
        
        # Compare distance metrics for KNN
        best_metric_tfidf = best_knn_tfidf['metric']
        best_metric_one_hot = best_knn_one_hot['metric']
        
        print(f"2. For KNN with TF-IDF, the {best_metric_tfidf} metric performs best.")
        print(f"3. For KNN with one-hot encoding, the {best_metric_one_hot} metric performs best.")
        
        # Compare model types
        if (best_knn_tfidf['f1'] > lr_results_tfidf['f1']) and (best_knn_one_hot['f1'] > lr_results_one_hot['f1']):
            print("4. KNN consistently outperforms Logistic Regression across both encoding methods.")
        elif (best_knn_tfidf['f1'] < lr_results_tfidf['f1']) and (best_knn_one_hot['f1'] < lr_results_one_hot['f1']):
            print("4. Logistic Regression consistently outperforms KNN across both encoding methods.")
        else:
            print("4. The performance of model types varies by encoding method.")
        
        print("\nTask 3 completed successfully!")
        
    except Exception as e:
        print(f"Error: {e}")
        print("Note: This script is meant to be a template. In the actual notebook, you would use the real matrices from Task 1.")

if __name__ == "__main__":
    main()
