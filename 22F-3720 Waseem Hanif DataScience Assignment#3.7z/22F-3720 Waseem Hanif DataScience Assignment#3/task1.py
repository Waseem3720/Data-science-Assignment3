#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import ast
import re
import warnings
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

# Set plotting style
plt.style.use('ggplot')

def parse_list(list_str):
    """
    Function to safely parse stringified lists
    """
    if pd.isna(list_str) or list_str == '[]':
        return []
    
    try:
        # Try to parse with ast.literal_eval
        return ast.literal_eval(list_str)
    except (SyntaxError, ValueError):
        # If that fails, try a regex-based approach
        matches = re.findall(r"'([^']*)'", list_str)
        if matches:
            return matches
        return []

def list_to_string(lst):
    """
    Function to convert list to string
    """
    if not lst:
        return ""
    return " ".join(str(item).lower() for item in lst)

def main():
    # Load the dataset
    print("Loading disease_features.csv...")
    disease_features = pd.read_csv('disease_features.csv')
    
    # Display basic information about the dataset
    print("\nDataset Information:")
    print(f"Shape: {disease_features.shape}")
    print(f"Columns: {', '.join(disease_features.columns)}")
    print(f"Number of diseases: {len(disease_features)}")
    
    # Parse and convert to strings for analysis
    print("\nParsing and processing data...")
    disease_features['Risk_Factors_List'] = disease_features['Risk Factors'].apply(parse_list)
    disease_features['Symptoms_List'] = disease_features['Symptoms'].apply(parse_list)
    disease_features['Signs_List'] = disease_features['Signs'].apply(parse_list)
    
    # Convert lists to strings for text analysis
    disease_features['Risk_Factors_Text'] = disease_features['Risk_Factors_List'].apply(list_to_string)
    disease_features['Symptoms_Text'] = disease_features['Symptoms_List'].apply(list_to_string)
    disease_features['Signs_Text'] = disease_features['Signs_List'].apply(list_to_string)
    
    # Count the number of features for each disease
    disease_features['Risk_Factors_Count'] = disease_features['Risk_Factors_List'].apply(len)
    disease_features['Symptoms_Count'] = disease_features['Symptoms_List'].apply(len)
    disease_features['Signs_Count'] = disease_features['Signs_List'].apply(len)
    disease_features['Total_Features'] = (
        disease_features['Risk_Factors_Count'] + 
        disease_features['Symptoms_Count'] + 
        disease_features['Signs_Count']
    )
    
    # Display summary statistics
    print("\nFeature Count Summary Statistics:")
    summary_stats = disease_features[['Risk_Factors_Count', 'Symptoms_Count', 'Signs_Count', 'Total_Features']].describe()
    print(summary_stats)
    
    # Create visualization 1: Average feature counts
    print("\nCreating visualization 1: Average feature counts...")
    avg_counts = [
        disease_features['Risk_Factors_Count'].mean(),
        disease_features['Symptoms_Count'].mean(),
        disease_features['Signs_Count'].mean()
    ]
    
    plt.figure(figsize=(10, 6))
    bars = plt.bar(['Risk Factors', 'Symptoms', 'Signs'], avg_counts, color=['#ff9999', '#66b3ff', '#99ff99'])
    
    # Add value labels on top of bars
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                 f'{height:.1f}', ha='center', va='bottom')
    
    plt.title('Average Number of Features per Disease', fontsize=16)
    plt.ylabel('Average Count', fontsize=12)
    plt.xlabel('Feature Type', fontsize=12)
    plt.tight_layout()
    plt.savefig('feature_distribution.png')
    print("Saved feature_distribution.png")
    
    # Create visualization 2: Feature counts by disease
    print("\nCreating visualization 2: Feature counts by disease...")
    plt.figure(figsize=(12, 8))
    
    # Sort diseases by total feature count for better visualization
    sorted_data = disease_features.sort_values('Total_Features', ascending=False)
    
    # Create stacked bar chart
    bottom_bars = np.zeros(len(sorted_data))
    
    for column, color in zip(['Risk_Factors_Count', 'Symptoms_Count', 'Signs_Count'], 
                            ['#ff9999', '#66b3ff', '#99ff99']):
        plt.bar(sorted_data['Disease'], sorted_data[column], bottom=bottom_bars, 
                label=column.replace('_Count', ''), color=color)
        bottom_bars += sorted_data[column].values
    
    plt.title('Number of Features by Disease', fontsize=16)
    plt.ylabel('Count', fontsize=12)
    plt.xlabel('Disease', fontsize=12)
    plt.xticks(rotation=90)
    plt.legend(title='Feature Type')
    plt.tight_layout()
    plt.savefig('disease_feature_counts.png')
    print("Saved disease_feature_counts.png")
    
    print("\nAnalysis complete!")

if __name__ == "__main__":
    main()
