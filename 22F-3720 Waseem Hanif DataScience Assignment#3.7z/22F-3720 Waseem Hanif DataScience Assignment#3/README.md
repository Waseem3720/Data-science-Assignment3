# Assignment 3 - Task 1

## Overview
This task analyzes the disease_features.csv dataset, which contains information about various diseases, their risk factors, symptoms, signs, and subtypes.

## Files
- `disease_features.csv`: The dataset containing disease information
- `task1.py`: Python script that performs the analysis
- `feature_distribution.png`: Generated visualization showing average feature counts
- `disease_feature_counts.png`: Generated visualization showing feature counts by disease

## How to Run
To run the analysis, execute the following command in your terminal:

```
python task1.py
```

## What the Script Does
1. Loads the disease_features.csv file
2. Cleans and processes the data, particularly converting string representations of lists to actual Python lists
3. Counts the number of risk factors, symptoms, and signs for each disease
4. Creates visualizations of the feature distributions
5. Saves the visualizations as PNG files

## Requirements
- Python 3.x
- pandas
- matplotlib
- numpy

## Expected Output
The script will print information about the dataset and save two visualization files:
1. `feature_distribution.png`: A bar chart showing the average number of features per disease
2. `disease_feature_counts.png`: A bar chart showing the feature counts for each disease
